project contains frontend folder
